# Run report

Status: stopped

Grade: RED

Reason: human declined approval

Actions: 6/25

No successful repair is claimed. Inspect timeline.jsonl and execution.log (if present) for evidence.
