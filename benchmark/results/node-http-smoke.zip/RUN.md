# Run this verified candidate

Source: `fixture://node-http`

Snapshot: `eb73afc2b833471a6f948f74bd3a264c86f66b58a940a122f31f5e29d95e86d0`

Unzip the evidence bundle. From its root, run:

```sh
docker build -t reporunner-candidate -f Dockerfile source
docker run --rm --network none --cap-drop ALL --security-opt no-new-privileges:true --memory 512m --cpus 1 reporunner-candidate
```

For a web entrypoint, publish its port explicitly on a trusted Docker network. The independent HTTP probe in this run uses port 8000 inside the sandbox.

Check evidence.json and the test/rebuild logs for actual outcomes. A generated Dockerfile alone is not a success claim.
