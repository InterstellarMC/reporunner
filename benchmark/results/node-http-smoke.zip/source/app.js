require('node:http').createServer((req,res)=>{res.setHeader('Content-Type','text/html');res.end('<h1>Actual Node HTTP response</h1>')}).listen(process.env.PORT||3000,'0.0.0.0');
