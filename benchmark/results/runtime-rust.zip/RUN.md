# Run this verified candidate

Source: `fixture://rust`

Snapshot: `235a91db8c801ef0f379e478d3a0fc036c8fa912a1ec609e7a8e4db8e7f149eb`

Unzip the evidence bundle. From its root, run:

```sh
docker build -t reporunner-candidate -f Dockerfile source
docker run --rm --network none --cap-drop ALL --security-opt no-new-privileges:true --memory 2048m --cpus 1 reporunner-candidate
```

For a web entrypoint, publish its port explicitly on a trusted Docker network. The independent HTTP probe in this run uses port 8000 inside the sandbox.

Check evidence.json and the test/rebuild logs for actual outcomes. A generated Dockerfile alone is not a success claim.
