#[test]
fn sum() { assert_eq!(rr_smoke::sum(2,3),5); assert_eq!(itoa::Buffer::new().format(5),"5"); }
