package smoke
import ("testing"; "github.com/google/uuid")
func TestSum(t *testing.T) { if Sum(2,3)!=5 || uuid.Nil.String()=="" { t.Fatal("sum") } }
