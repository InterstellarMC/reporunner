# Run this verified candidate

Source: `fixture://dotnet`

Snapshot: `34147310026869e632e24e4aa61f1d0568bd7336a2a2af77474d820fdcab57de`

Unzip the evidence bundle. From its root, run:

```sh
docker build -t reporunner-candidate -f Dockerfile source
docker run --rm --network none --cap-drop ALL --security-opt no-new-privileges:true --memory 2048m --cpus 1 reporunner-candidate
```

For a web entrypoint, publish its port explicitly on a trusted Docker network. The independent HTTP probe in this run uses port 8000 inside the sandbox.

Check evidence.json and the test/rebuild logs for actual outcomes. A generated Dockerfile alone is not a success claim.
