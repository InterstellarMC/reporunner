# Run this verified candidate

Source: `fixture://node-import`

Snapshot: `1345ad0639964de2868d83229e91337893459252422f2a4772a6524737c558e7`

Unzip the evidence bundle. From its root, run:

```sh
docker build -t reporunner-candidate -f Dockerfile source
docker run --rm --network none --cap-drop ALL --security-opt no-new-privileges:true --memory 512m --cpus 1 reporunner-candidate
```

For a web entrypoint, publish its port explicitly on a trusted Docker network. The independent HTTP probe in this run uses port 8000 inside the sandbox.

Check evidence.json and the test/rebuild logs for actual outcomes. A generated Dockerfile alone is not a success claim.
