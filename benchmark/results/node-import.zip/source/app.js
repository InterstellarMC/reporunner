module.exports = require('./multiplier');
